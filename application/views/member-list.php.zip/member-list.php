<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

    <div class="col col-lg-6">
		<form class="form-inline" method="post" action="<?php echo base_url(); ?>member_list/index">
			<div class="form-group mb-2">
			<label>Masukkan kata kunci</label>

			</div>
			<div class="form-group mx-sm-3 mb-2">
			<label for="inputPassword2" class="sr-only">Password</label>
			<input type="text" class="form-control" name="txt_cari" value="<?= $cari; ?>" placeholder="Nama or Username">
			</div>
			<button type="submit" class="btn btn-primary mb-2">Cari</button>
		</form>
		
    </div>
	<div class="col col-lg-6">
		Total Member: <?= $tot_hal; ?>
    
    </div>
</div>   
<br />

<div class="container">
    <table  class="table table-striped">
        <tr>
            <th>No</th>
            <th>Username</th>
            <th>Nama</th>
            <th>Pin</th>
            <th>Sponsor</th>
            <th>Nama Sponsor</th>
            <th>Status</th>
            <th>#</th>
            <th># </th>  
            <th>Action</th>
        </tr>
        <?php
        $nom=$hal+1;
        foreach($lst_member->result_array() as $db){
            $username = $db['username'];
            $pass = $db['pin'];
            //$status = check_status($username, $pass);
            if($db['alamat'] == ""){
                $alamat = "-";
            } else {
                $alamat = $db['alamat'];
                
            }
           
            $nama_sponsor = $this->data_model->dataku("nama",$db['sponsor']);
            if($db['blokir'] <> 1){
                
                $status='Aktif';
            } else {
              
                $status='Suspend';
                
            }
        ?>
        <tr>
            <td style="text-align:center"><?= $nom; ?></td>
            <td style="text-align:center"><?= $db['username']; ?></td>
            <td><?= $db['nama']; ?></td>
            <td style="text-align:center"><?= $db['pin']; ?></td>
            <td><?= $db['sponsor']; ?></td>
            <td><?= $nama_sponsor; ?></td>
            <td><?= $status; ?></td>
            <td><a href="<?php echo base_url(); ?>member_list/register_ppob?username=<?= $db['username']; ?>&alamat=<?= $alamat; ?>&pass=<?= $db['pin']; ?>&nama=<?= $db['nama']; ?>"><input type="button" class="btn btn-primary" value="Reg PPOB"></a></td>
            <td><a href="<?php echo base_url(); ?>member_list/reset_password?username=<?= $db['username']; ?>&pass=<?= $db['pin']; ?>">
              <input type="button" class="btn btn-success" value="Reset Password"></a></td>
            <?php
              if($db['blokir'] <> 1){
            ?>
            <td><a href="<?php echo base_url(); ?>member_list/blokir?username=<?= $username; ?>&keywrd=<?= $cari; ?>&per_page=<?= $page; ?>"><input type="button" class="btn btn-info" value="Blokir"></a></td>
            <?php
              } else {
            ?>
            <td><a href="<?php echo base_url(); ?>member_list/unblokir?username=<?= $username; ?>&keywrd=<?= $cari; ?>&per_page=<?= $page; ?>"><input type="button" class="btn btn-warning" value="unBlokir"></a></td>
            <?php
              }
            ?>
        </tr>
        <?php
        $nom++;
        }
        ?>
    </table>
	<center>Total Member: <?= $tot_hal; ?></center>
    <div class="pagination"><?php echo $paginator; ?></div>

</div>

</body>
</html>